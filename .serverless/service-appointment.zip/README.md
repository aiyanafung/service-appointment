# Appointment Service

A Serverless AWS Lambda + DynamoDB backend for scheduling service appointments.

## Setup
npm install

