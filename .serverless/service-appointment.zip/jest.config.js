module.exports = {
    testEnvironment: 'node',
};