'use strict';

function log(message, ...args) {
    console.log(message, ...args);
}

module.exports = { log };