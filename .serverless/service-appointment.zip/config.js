'use strict';

module.exports = {
    APPOINTMENTS_TABLE: process.env.APPOINTMENTS_TABLE,
    API_KEY: process.env.API_KEY,
};